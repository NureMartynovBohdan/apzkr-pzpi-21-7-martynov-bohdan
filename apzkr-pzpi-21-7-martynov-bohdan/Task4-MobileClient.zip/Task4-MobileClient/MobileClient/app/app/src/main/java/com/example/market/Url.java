package com.example.market;

public class Url {
        private static final String ROOT_URL = "http://192.168.1.101/mobile/"; //ipconfig  IPv4 Address
    public static final String URL_SIGNUP = ROOT_URL+"signUp.php";
    public static final String URL_LOGIN = ROOT_URL+"logIn.php";
    public static final String URL_LOGOUT = ROOT_URL+"logOut.php";

}
