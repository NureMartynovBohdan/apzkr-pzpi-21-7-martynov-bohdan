<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "moda_test";

// Подключения
$conn = new mysqli($servername, $username, $password, $dbname);
