<?php require "./languages/language.php" ?>

<footer class="text-body-secondary py-5">
  <div class="container">
    <p class="float-end mb-1">
      <a href="#">Вверх</a>
    </p>
    <p class="mb-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad, cumque! Ad, cumque! Ad, cumque!</p>
    <p class="mb-0">Lorem, ipsum dolor? <a href="./web/index.php">Відвідати початкову сторінку</a>або ознайомитися з<a href="/">Умовами використання</a> сайту.</p>
  </div>
</footer>